$(document).ready(function()
{
    /* expand active tree. */
    $('.tree li.active .hitarea').click();
});
