<?php
if(!isset($config->trip)) $config->trip = new stdclass();
$config->trip->require = new stdclass();
$config->trip->require->create = 'name,year,begin,end,from,to';
$config->trip->require->edit   = 'name,year,begin,end,from,to';
