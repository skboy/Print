<?php
$lang->attend->clientList['xuanxuan'] = 'Xuanxuan';
