<?php
/**
 * The view readers view file of announce module of RanZhi.
 *
 * @copyright   Copyright 2009-2018 青岛易软天创网络科技有限公司(QingDao Nature Easy Soft Network Technology Co,LTD, www.cnezsoft.com)
 * @license     ZPL (http://zpl.pub/page/zplv12.html)
 * @author      Gang Liu <liugang@cnezsoft.com>
 * @package     announce 
 * @version     $Id$
 * @link        http://www.ranzhi.org
 */
?>
<?php include '../../../sys/common/view/header.modal.html.php';?>
<div style='word-wrap:break-word;word-break:break-all;'>
  <?php echo $readers;?>
</div>
<?php include '../../../sys/common/view/footer.modal.html.php';?>

